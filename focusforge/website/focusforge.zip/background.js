// background.js

// Initial state
const defaultSettings = {
  blocklist: ["instagram.com", "youtube.com", "reddit.com"],
  dailyUsage: {},
  focusSessions: [],
  points: 0,
  level: "Novice",
  streak: 0,
  settings: { dailyGoal: 7200, sessionLength: 25 * 60 } // seconds
};

// Initialize Storage
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(null, (data) => {
    if (Object.keys(data).length === 0) {
      chrome.storage.local.set(defaultSettings);
    }
    updateBlockingRules();
  });
});

// Focus Session State
let isFocusActive = false;
let sessionEndTime = 0;

// Listen for alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "focus_session_end") {
    endFocusSession(true);
  }
});

// Update DeclarativeNetRequest Rules dynamically based on blocklist and focus state
async function updateBlockingRules() {
  const data = await chrome.storage.local.get(["blocklist"]);
  const blocklist = data.blocklist || [];
  
  const rules = blocklist.map((domain, index) => ({
    id: index + 1,
    priority: 1,
    action: {
      type: "redirect",
      redirect: { extensionPath: "/blocked.html?url=" + encodeURIComponent(domain) }
    },
    condition: {
      urlFilter: domain,
      resourceTypes: ["main_frame"]
    }
  }));

  // If focus is NOT active, we remove all rules to allow browsing, 
  // OR we keep rules but handle them differently. The requirements state: 
  // "During focus sessions, these sites show a Blocked page".
  // So we only enforce block rules if focus is active.
  if (isFocusActive) {
    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: Array.from({length: 100}, (_, i) => i + 1), // clear old
      addRules: rules
    });
  } else {
    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: Array.from({length: 100}, (_, i) => i + 1)
    });
  }
}

// Start focus session
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "START_FOCUS") {
    const durationMs = request.duration * 1000;
    sessionEndTime = Date.now() + durationMs;
    isFocusActive = true;
    
    chrome.alarms.create("focus_session_end", { delayInMinutes: request.duration / 60 });
    updateBlockingRules();
    
    sendResponse({ success: true, sessionEndTime });
  } else if (request.action === "STOP_FOCUS") {
    endFocusSession(false);
    sendResponse({ success: true });
  } else if (request.action === "GET_FOCUS_STATE") {
    sendResponse({ isFocusActive, sessionEndTime });
  } else if (request.action === "TEMPORARY_UNBLOCK") {
    // We add this domain to a temporary allow list for 10 minutes
    const domain = request.domain;
    // For simplicity, we just rebuild the rules without this domain
    // A robust solution would set a timer to re-add it.
    chrome.storage.local.get(["blocklist"], (data) => {
      let blocklist = data.blocklist || [];
      // Remove it from the current enforced rules
      const ruleIdToRemove = blocklist.indexOf(domain) + 1;
      if (ruleIdToRemove > 0) {
        chrome.declarativeNetRequest.updateDynamicRules({
          removeRuleIds: [ruleIdToRemove]
        });
        
        // Re-add after 10 mins (600000ms)
        setTimeout(() => {
          if (isFocusActive) updateBlockingRules();
        }, 600000);
      }
    });
    sendResponse({ success: true });
  }
});

async function endFocusSession(completed) {
  isFocusActive = false;
  sessionEndTime = 0;
  chrome.alarms.clear("focus_session_end");
  updateBlockingRules();

  if (completed) {
    // Gamification Updates
    const data = await chrome.storage.local.get(["points", "level", "focusSessions"]);
    let points = data.points || 0;
    let focusSessions = data.focusSessions || [];
    
    let earnedPoints = 10;
    points += earnedPoints;
    let level = "Novice";
    if (points >= 3000) level = "Legend";
    else if (points >= 1500) level = "Master";
    else if (points >= 500) level = "Apprentice";

    focusSessions.push({ date: new Date().toISOString().split('T')[0], duration: 25 * 60, completed: true });
    
    await chrome.storage.local.set({ 
      points, 
      level, 
      focusSessions,
      unclaimedReward: true,
      lastRewardPoints: earnedPoints
    });
    
    // Notify User
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: "FocusForge",
      message: "Focus session complete! +10 points 🔥"
    });
  }
}

// Time Tracking
let currentTabId = null;
let currentDomain = null;
let lastTimeUpdated = Date.now();

chrome.tabs.onActivated.addListener((activeInfo) => {
  updateTime();
  currentTabId = activeInfo.tabId;
  checkTabDomain(currentTabId);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tabId === currentTabId && changeInfo.url) {
    updateTime();
    checkTabDomain(currentTabId);
  }
});

chrome.windows.onFocusChanged.addListener((windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    updateTime();
    currentTabId = null;
    currentDomain = null;
  } else {
    chrome.tabs.query({ active: true, windowId: windowId }, (tabs) => {
      if (tabs[0]) {
        updateTime();
        currentTabId = tabs[0].id;
        checkTabDomain(currentTabId);
      }
    });
  }
});

function getDomain(url) {
  try {
    let hostname = new URL(url).hostname;
    hostname = hostname.replace(/^www\./, '');
    return hostname;
  } catch (e) {
    return null;
  }
}

function checkTabDomain(tabId) {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab.url) {
      currentDomain = null;
      return;
    }
    currentDomain = getDomain(tab.url);
    lastTimeUpdated = Date.now();
  });
}

function updateTime() {
  if (currentDomain && lastTimeUpdated) {
    const timeSpent = Math.floor((Date.now() - lastTimeUpdated) / 1000); // in seconds
    if (timeSpent > 0 && timeSpent < 3600 * 2) { // sanity check
      chrome.storage.local.get(["dailyUsage"], (data) => {
        let dailyUsage = data.dailyUsage || {};
        dailyUsage[currentDomain] = (dailyUsage[currentDomain] || 0) + timeSpent;
        chrome.storage.local.set({ dailyUsage });
      });
    }
  }
  lastTimeUpdated = Date.now();
}

// Initial time tracking setup
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  if (tabs[0]) {
    currentTabId = tabs[0].id;
    checkTabDomain(currentTabId);
  }
});

// Periodic saving just in case
setInterval(() => {
  updateTime();
}, 10000);
